package cs520.model;

public enum UserRole {

	ADMIN, STAFF,STUDENT
}
