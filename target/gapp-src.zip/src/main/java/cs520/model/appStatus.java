package cs520.model;

public enum appStatus {
	
	New(1),PendingReview(2),Denied(3),RecommendAdmit(4),RecommendAdmitWithCondition(5),Saved(6);
	
	private final int value;
	
	appStatus(int value) { this.value = value; }
	
    public int getValue() { return value; }
    
}

