package cs520.model.dao;

import java.util.List;

import cs520.model.Application;

public interface ApplicationDao {
	
	 Application getApplication( Integer id );
	  
	  List<Application> getApplications();

	  List<Application> getApplicationsByDepartment(String dept);
	  
	Application addApplication(Application app);

}
