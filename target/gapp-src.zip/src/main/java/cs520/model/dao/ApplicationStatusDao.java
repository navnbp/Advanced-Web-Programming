package cs520.model.dao;

import cs520.model.ApplicationStatus;

public interface ApplicationStatusDao {
	
	ApplicationStatus getApplicationStatus(Integer id);

}
