package cs520.model.dao;

import cs520.model.Role;

public interface RoleDao {

	Role getRoleByName(String name);
}
