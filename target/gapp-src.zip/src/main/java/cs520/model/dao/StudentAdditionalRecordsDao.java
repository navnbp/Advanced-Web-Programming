package cs520.model.dao;


import java.util.List;

import cs520.model.StudentAdditionalRecords;

public interface StudentAdditionalRecordsDao {
	
	StudentAdditionalRecords addRecords(StudentAdditionalRecords record);
	
	List<StudentAdditionalRecords> getRecords();

	StudentAdditionalRecords getRecords(int id);
	
	 void deleteAdditionalRecords(Integer id);
}
