package cs520.model.dao;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.testng.AbstractTransactionalTestNGSpringContextTests;
import org.testng.annotations.Test;


@Test(groups = "ApplicationDaoTests")
@ContextConfiguration(locations = "classpath:applicationContext.xml")
public class DepartmentDaoTest  extends AbstractTransactionalTestNGSpringContextTests {

	
	 @Autowired
	DepartmentDao departmentDao;
	 /*@Test
	 public void testCaseForDepartmentCount()
	 {
		 assert departmentDao.getDepartments().size()==2;
		
	}*/
	
}
